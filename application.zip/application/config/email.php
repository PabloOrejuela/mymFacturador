<?php
$config['protocol'] = "smtp";
$config['smtp_host'] = "ssl://smtp.gmail.com";
$config['smtp_port'] = "465";
$config['smtp_user'] = "vitelopers@gmail.com"; 
$config['smtp_pass'] = "Dotylive007";
$config['charset'] = "utf-8";
$config['mailtype'] = "html";
$config['newline'] = "\r\n";

//$config['protocol'] = "smtp";
//$config['smtp_host'] = "mx1.nixiweb.com";
//$config['smtp_port'] = "2525";
//$config['smtp_user'] = "desarrollo@katonproyect.tk"; 
//$config['smtp_pass'] = "212111007";
//$config['charset'] = "utf-8";
//$config['mailtype'] = "html";
//$config['newline'] = "\r\n";